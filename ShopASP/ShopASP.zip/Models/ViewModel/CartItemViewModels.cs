﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShopASP.Models.ViewModel
{
    public class CartItemViewModels
    {
        public int IdProduct { get; set; }
        public int quantity { get; set; }
    }
}